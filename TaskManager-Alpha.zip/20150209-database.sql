-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Gegenereerd op: 08 feb 2015 om 13:57
-- Serverversie: 5.5.37
-- PHP-versie: 5.4.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mvlc_taskmgr`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `subteam`
--

CREATE TABLE IF NOT EXISTS `subteam` (
  `id` int(11) NOT NULL,
  `subteamnaam` varchar(40) NOT NULL,
  `idteam` int(10) NOT NULL,
  `idopleidingsverantwoordelijke` int(11) NOT NULL,
  `actief` int(1) NOT NULL,
  `teamid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `subteam`
--

INSERT INTO `subteam` (`id`, `subteamnaam`, `idteam`, `idopleidingsverantwoordelijke`, `actief`, `teamid`) VALUES
(2, 'Applicatieontwikkelaar', 1, 2, 0, 0),
(5, 'Mediasmurfen', 1, 4, 1, 0),
(6, 'electrotechniek', 2, 3, 1, 0),
(7, 'nietsnutten', 2, 3, 1, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `subteamdocenten`
--

CREATE TABLE IF NOT EXISTS `subteamdocenten` (
  `id` int(11) NOT NULL,
  `subteamid` int(11) NOT NULL,
  `werknemerid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `subteamdocenten`
--

INSERT INTO `subteamdocenten` (`id`, `subteamid`, `werknemerid`) VALUES
(1, 2, 1),
(2, 2, 4),
(3, 1, 120),
(5, 2, 20),
(6, 2, 8),
(13, 2, 18);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `taken`
--

CREATE TABLE IF NOT EXISTS `taken` (
  `id` int(10) NOT NULL,
  `subteam` int(10) NOT NULL,
  `code` varchar(10) NOT NULL,
  `soort` varchar(30) NOT NULL,
  `naam` varchar(50) NOT NULL,
  `beschrijving` text NOT NULL,
  `klokuren` float(4,2) NOT NULL,
  `lesuren` float(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `team`
--

CREATE TABLE IF NOT EXISTS `team` (
  `id` int(11) NOT NULL,
  `teamnaam` varchar(30) NOT NULL,
  `idteamleider` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `team`
--

INSERT INTO `team` (`id`, `teamnaam`, `idteamleider`) VALUES
(1, 'ICT', 1),
(2, 'Electro', 4);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `teamdocenten`
--

CREATE TABLE IF NOT EXISTS `teamdocenten` (
  `id` int(11) NOT NULL,
  `teamid` int(11) NOT NULL,
  `werknemerid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemer`
--

CREATE TABLE IF NOT EXISTS `werknemer` (
  `id` int(11) NOT NULL,
  `aanhef` varchar(15) NOT NULL,
  `voorletters` varchar(10) NOT NULL,
  `voornaam` varchar(30) NOT NULL,
  `tussenvoegsel` varchar(30) NOT NULL,
  `achternaam` varchar(30) NOT NULL,
  `straat` varchar(50) NOT NULL,
  `huisnummer` int(10) NOT NULL,
  `woonplaats` varchar(50) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `indienstneming` date NOT NULL,
  `wtf` float(2,2) NOT NULL,
  `userlevel` varchar(3) NOT NULL,
  `functie` varchar(40) NOT NULL,
  `wachtwoord` varchar(36) NOT NULL,
  `actief` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `werknemer`
--

INSERT INTO `werknemer` (`id`, `aanhef`, `voorletters`, `voornaam`, `tussenvoegsel`, `achternaam`, `straat`, `huisnummer`, `woonplaats`, `postcode`, `email`, `indienstneming`, `wtf`, `userlevel`, `functie`, `wachtwoord`, `actief`) VALUES
(1, '', 'Admin', 'Admin', 'Admin', 'Admin', 'Admin', 0, 'Admin', '', 'admin@admin', '2014-09-03', 0.99, '4', 'Docent', 'admin', 1),
(2, 'Dhr.', 'B', 'Bram', 'van', 'Huele', 'niet van toepassing', 0, 'niet van toepassing', '', 'bvanhuele@scalda.nl', '2014-10-10', 0.99, '2', 'Opleidingverantwoordelijke', 'bram123', 0),
(3, 'Dhr.', 'H.A', 'Huberto', 'van den', 'Hoven', 'Rustenburg', 8, 'middelburg', '4337vv', 'huberto1994@hotmail.com', '2014-10-21', 0.99, '4', 'Docent', 'icolaco', 0),
(4, 'Dhr.', 'M', 'Maik', 'van', 'Lieshout', 'Langeweg', 3, 'Nieuw- en Sint Joosland', '4339NA', 'maikvanlieshout@gmail.com', '2014-10-30', 0.00, '4', 'Docent', 'welkom123', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `werknemertaken`
--

CREATE TABLE IF NOT EXISTS `werknemertaken` (
  `id` int(10) NOT NULL,
  `taakid` int(10) NOT NULL,
  `werknemerid` int(10) NOT NULL,
  `taakjaar` date NOT NULL,
  `inzetbaarko` float(4,2) NOT NULL,
  `inzetbaarlo` float(4,2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `werknemertaken`
--

INSERT INTO `werknemertaken` (`id`, `taakid`, `werknemerid`, `taakjaar`, `inzetbaarko`, `inzetbaarlo`) VALUES
(1, 1, 2, '2015-02-07', 0.00, 15.50);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `subteam`
--
ALTER TABLE `subteam`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `subteamdocenten`
--
ALTER TABLE `subteamdocenten`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `taken`
--
ALTER TABLE `taken`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexen voor tabel `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `teamdocenten`
--
ALTER TABLE `teamdocenten`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `werknemer`
--
ALTER TABLE `werknemer`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `werknemertaken`
--
ALTER TABLE `werknemertaken`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `subteam`
--
ALTER TABLE `subteam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT voor een tabel `subteamdocenten`
--
ALTER TABLE `subteamdocenten`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT voor een tabel `taken`
--
ALTER TABLE `taken`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT voor een tabel `team`
--
ALTER TABLE `team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT voor een tabel `werknemer`
--
ALTER TABLE `werknemer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT voor een tabel `werknemertaken`
--
ALTER TABLE `werknemertaken`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
